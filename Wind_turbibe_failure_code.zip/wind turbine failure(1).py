import matplotlib.pyplot as plt  # Library for creating plots and visualizations
import numpy as np  # Library for numerical computing
import pandas as pd  # Library for data manipulation and analysis
import seaborn as sns  # Library for creating plots and visualizations


df = pd.read_csv(r"C:\Users\HP\Downloads\Data Set (4)\Wind_turbine.csv")

#Show the first five row in the data
df.head()

#Display information about the DataFrame
df.info()
# Checking the shape of the education data
df.shape

#Desctibe the data
df.describe()
#Find the duplicate value 
df.duplicated().sum()

#First business moment decision
#Find the mean
df.mean()
#Find the median
df.median()
#Find the mode
df.mode()

#Second moment business decision
#Find varience
df.var()
#Find standard deviation
df.std()
#Find the range
ranges = df.max(numeric_only=True) - df.min(numeric_only=True)
ranges

#Third moment business decision
#Find the skewness
skew_values=df.skew(numeric_only=True)
print(skew_values)

#Fourth moment business decision
#Find the kurtosis
kurtosis_values=df.kurt(numeric_only=True)
print(kurtosis_values)


#Checking missing value in the data
df.isnull().sum()
#drop missing value
df.dropna(inplace = True)


df['Failure_status'].value_counts().plot(kind = 'pie',autopct = '%0.0f%%')

df.columns

#Univarient analysis
col = ['date', 'Wind_speed', 'Power', 'Nacelle_ambient_temperature',
       'Generator_bearing_temperature', 'Gear_oil_temperature',
       'Ambient_temperature', 'Rotor_Speed', 'Nacelle_temperature',
       'Bearing_temperature)', 'Generator_speed', 'Yaw_angle',
       'Wind_direction', 'Wheel_hub_temperature', 'Gear_box_inlet_temperature']

# Filter numeric columns only
numeric_cols = df[col].select_dtypes(include='number').columns

# Loop over numeric columns to create individual boxplots
for i in numeric_cols:
    plt.figure(figsize=(8, 4))
    sns.boxplot(data=df, x=i)
    plt.title(f'Boxplot of {i}')
    plt.show() 
    
    
col = ['date', 'Wind_speed', 'Power', 'Nacelle_ambient_temperature',
       'Generator_bearing_temperature', 'Gear_oil_temperature',
       'Ambient_temperature', 'Rotor_Speed', 'Nacelle_temperature',
       'Bearing_temperature)', 'Generator_speed', 'Yaw_angle',
       'Wind_direction', 'Wheel_hub_temperature', 'Gear_box_inlet_temperature']

# Filter numeric columns only
numeric_cols = df[col].select_dtypes(include='number').columns

# Loop over numeric columns to create individual boxplots
for i in numeric_cols:
    plt.figure(figsize=(8, 4))
    sns.distplot( df[i])
    plt.title(f'Boxplot of {i}')
    plt.show()
 
    #to check column
df.head()

#Bivariant analysis
#doing barplot with column 'wind_speed' and 'Failure_status
sns.barplot(data=df,x='Wind_speed',y='Failure_status') 
#doing barplot with column 'Power' and 'Failure_status
sns.barplot(data=df,x='Power',y='Failure_status',)

#doing scatter plot with column 'wind_speed' and 'Power'to check failure status
sns.scatterplot(data = df, x = df['Wind_speed'],y = df['Power'],hue = df['Failure_status'])

"""
Observations:
Power Distribution for Failures:

Low Wind Speeds: Failures (orange points) are concentrated at very low wind speeds (near 0).
Power Levels: Power values are notably higher (near 10-12) even at low wind speeds during failures, which could indicate overloading or misalignment between power and wind speed.
Power Distribution for No Failures:

Higher Wind Speeds: "No_failure" points (blue) are spread across a wide range of wind speeds (0 to 50).
Power Levels: Power tends to scale more proportionally with wind speed, peaking around 6 at moderate wind speeds (10-30).
Clusters:

There's a clear cluster of failure points at low wind speed but high power output.
Another distinct cluster of no-failure points at higher wind speeds with proportional power output.
Insights:
High Power at Low Wind Speeds:

Failures occurring at very low wind speeds but high power outputs suggest operational stress. This could indicate a system malfunction or overproduction attempts beyond safe limits.
Stable Performance at Moderate Wind Speeds:

For turbines with no failures, power output scales proportionally with wind speed, suggesting stable performance at moderate wind speeds.
Potential Wind Speed Threshold:

Turbines operating at wind speeds below 5 with power above 10 seem highly prone to failure. This could serve as a threshold for operational safeguards.
Recommendations:
System Monitoring:

Investigate why failures occur at low wind speeds with high power output. This could involve misaligned turbine settings or excessive stress on components.
Threshold Implementation:

Limit power generation at low wind speeds to avoid potential failures.
Further Analysis:

Examine other variables like gear temperature, rotor speed, and bearing performance in combination with these factors to better understand failure causes.
"""
#doing scatter plot with column 'wind_speed' and 'Rotor_Speed'to check failure status
sns.scatterplot(data = df, x = df['Wind_speed'],y = df['Rotor_Speed'],hue = df['Failure_status']) 

#doing barplot with all column to check failure status
df.columns
col = [ 'Wind_speed', 'Power', 'Nacelle_ambient_temperature',
       'Generator_bearing_temperature', 'Gear_oil_temperature',
       'Ambient_temperature', 'Rotor_Speed', 'Nacelle_temperature',
       'Bearing_temperature)', 'Generator_speed', 'Yaw_angle',
       'Wind_direction', 'Wheel_hub_temperature', 'Gear_box_inlet_temperature']
for i in col:
    sns.barplot(data=df,x= i,y='Failure_status')
    plt.show()


"""
->1 PLOT
Business Insights:

Higher Wind Speeds Lead to Failures:
The bar corresponding to "Failure" shows higher average wind speeds compared to the "No_failure" category.
This indicates that wind turbines are more likely to fail at higher wind speeds.

Safe Operating Threshold:
The "No_failure" category corresponds to lower wind speed ranges, suggesting that turbines operate safely within a specific wind speed range.

Business Decisions:

Define Wind Speed Safety Limits:
Implement wind speed thresholds for shutting down turbines during extreme wind events to minimize failures.
Define these limits based on detailed analysis of failure cases in higher wind speed ranges.

Optimize Turbine Design:
Invest in designing or upgrading turbines to handle higher wind speeds effectively without failure, reducing downtime and increasing energy generation.

->PLOT 2
Business Insights

Higher Power Levels Lead to Failures:
    The "Failure" category corresponds to higher average power output compared to the "No_failure" category.
This indicates that wind turbines are more prone to failure when operating at high power levels.

Safe Operating Power Range:
The "No_failure" category corresponds to relatively lower power outputs, suggesting that turbines are less likely to fail within a certain power range.

Business Decision:

Define Power Output Thresholds:
Establish safe power output thresholds to prevent turbines from operating at levels associated with higher failure risks.
Integrate these thresholds into turbine control systems for automatic adjustments.

->plot 3
Business Insights

Ambient Temperature and Failures:
The "Failure" category is associated with significantly lower nacelle ambient temperatures compared to the "No_failure" category.
This suggests that lower ambient temperatures might increase the likelihood of failures in wind turbines.

Safe Operating Temperature Range:
Turbines appear to operate safely within higher ambient temperature ranges, as indicated by the "No_failure" category.

Temperature as a Risk Factor:
    Extreme or low nacelle ambient temperatures might impact turbine performance, potentially leading to mechanical or operational failures.

Business Decisions

Establish Temperature Thresholds:
Define a minimum nacelle ambient temperature threshold to ensure safe operation and prevent failures.

Deploy Heating Systems:
Consider implementing heating systems for turbines operating in low-temperature environments to maintain optimal conditions.
"""

#doing scatter plot with column 'Yaw_angle' and 'Rotor_Speed'to check failure status
sns.scatterplot(data = df, x = df['Yaw_angle'],y = df['Rotor_Speed'],hue = df['Failure_status']) 

#doing scatter plot with column 'Yaw_angle' and 'Wind_speed' to check failure status
sns.scatterplot(data = df, x = df['Yaw_angle'],y = df['Wind_speed'],hue = df['Failure_status'])

#doing scatter plot with column 'Yaw_angle' and 'Wind_direction' to check failure status
sns.scatterplot(data = df, x = df['Yaw_angle'],y = df['Wind_direction'],hue = df['Failure_status'])

#doing scatter plot with column 'Gear_oil_temperature' and 'Generator_bearing_temperature' to check failure status
sns.scatterplot(data = df, x = df['Gear_oil_temperature'],y = df['Generator_bearing_temperature'],hue = df['Failure_status'])

df.columns
#convert Failure_status to value 0 or 1
df['Failure_status'] = np.where(df['Failure_status'] == 'Failure',1,0)
df.head()
#check the datatype of Failure_status
df['Failure_status'].dtype


numerical_columns = ['Wind_speed', 'Power', 'Nacelle_ambient_temperature',
                     'Generator_bearing_temperature', 'Gear_oil_temperature',
                     'Ambient_temperature', 'Rotor_Speed', 'Nacelle_temperature',
                     'Generator_speed', 'Yaw_angle', 'Wind_direction',
                     'Wheel_hub_temperature', 'Gear_box_inlet_temperature','Failure_status']  

# Filter the DataFrame for numerical columns 
df_numeric = df[numerical_columns] 

# Compute the correlation matrix 
correlation_matrix = df_numeric.corr() 

# Plot the heatmap 
plt.figure(figsize=(8, 6)) 
sns.heatmap(correlation_matrix, annot=True, fmt=".2f", cmap="coolwarm", cbar=True) 
plt.title("Heatmap of Numerical Features")  
plt.show()     